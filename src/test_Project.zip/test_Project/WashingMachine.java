package test_Project;

import repast.simphony.space.grid.Grid;

public class WashingMachine {
	private Grid<Object> grid;
	
	public WashingMachine(Grid<Object> grid) {
		
		this.grid = grid;
	}
}
