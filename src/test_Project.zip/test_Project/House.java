package test_Project;

import repast.simphony.space.continuous.ContinuousSpace;
import repast.simphony.space.grid.Grid;

public class House {
	
	private Grid<Object> grid;
	
	public House(Grid<Object> grid) {
		
		this.grid = grid;
	}
}
